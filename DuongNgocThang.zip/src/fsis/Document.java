package fsis;

public interface Document {
	String toHtmlDoc();
}
