package fsis;

import fsis.Customer;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Vector;
import fsis.DomainConstraint;

/**
 * @overview 
 * Sorted are mutable, unbounded sets of customer.
 * @attributes 
 * els Set<Customer> Vector<Customer>
 * @object 
 * A typical Sorted object is c={c1,...,cn}, where c1,...,cn are
 * elements.
 * @abstract_properties 
 * optional(elements) = false /\ for all x in elements. x
 * is integer /\ for all x, y in elements. x neq y
 * @abstraction_function
 * AF(c) = {x| x=y.intValue /\ y=c.elements[i] /\ 0 <= i <
 * c.els.size} @rep_invariant els != null /\ for all integers i. els[i] is an
 * Integer /\ for all integers i,j. (0 <= i < j < els.size => els[i].intValue !=
 * els[j].intValue)
 * @author ThangDuong
 */
public class SortedSet {

    @DomainConstraint(type = "Vector", optional = false)
    private Vector<Comparable> ele;

    /**
     * @effects initialize <tt>this</tt> to be empty
     */
    public SortedSet() {

        ele = new Vector();
    }

    

    

    /**
     * @effects return the size of <tt>this</tt>
     */
    public int size() {
        return ele.size();
    }

    /**
     * @effects <pre>
     *  if x is in this
     *    return the index where x appears
     *  else
     *    return -1</pre>
     */
    private int getIndex(Comparable cu) {
        for (int i = 0; i < ele.size(); i++) {
            if (cu.compareTo(ele.elementAt(i)) == 0) {
                return i;
            }
        }
        return -1;
    }
    
    /**
     * @effects <pre>
     *  if x is in this
     *    return true</pre>
     */
    public boolean isIn(Comparable cu) {
        return (getIndex(cu) >= 0);
    }

    /**
     * @effects   <pre>
     *            if this is empty
     *              throws an EmptyException
     *            else
     *              returns a generator of the elements of this </pre>
     *
     * @requires <tt>this</tt> this must not be modified while the generator is
     * in use
     */
    public Iterator elements() {
        return new SortedSet.IntSetGen();
    }

    @Override
    public String toString() {
        if (size() == 0) {
            return "Empty!";
        }

        String s = "Customers: " + ele.elementAt(0).toString();
        for (int i = 1; i < size(); i++) {
            s = s + " , " + ele.elementAt(i).toString();
        }

        return s;
    }

    /**
     * @effects <pre>
     *            if this satisfies abstract properties
     *              return true
     *            else
     *              return false</pre>
     */
    public boolean repOK() {
        if (ele == null) {
            return false;
        }

        for (int i = 0; i < ele.size(); i++) {
            Object obj = ele.get(i);

            if (!(obj instanceof Integer)) {
                return false;
            }

            for (int j = i + 1; j < ele.size(); j++) {
                if (ele.get(j).equals(obj)) {
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * @modifies <tt>this</tt>
     * @effects <pre>
     *              if x is already in this
     *                do nothing,
     *              else
     *                add x to this, i.e., this_post = this + {x}</pre>
     */
    public void insert(Comparable customer) {
        if (ele.size() > 0) {

            Iterator it = elements();

            while (it.hasNext()) {
                Customer cu = (Customer) it.next();
                if (cu.compareTo(customer) > 0 && getIndex(customer) < 0) {
                    ele.add(getIndex(cu), customer);
                    customer = cu;
                }
            }

            if (getIndex(customer) < 0) {
                ele.add(customer);
                return;
            }

        } else {
            ele.add(customer);
        }
    }

    /**
     * @modifies <tt>this</tt>
     * @effects <pre>
     *              if x is not in this
     *                  do nothing
     *              else
     *                remove x from this, i.e.
     *                this_post = this - {x}</pre>
     */
    public void remove(Comparable customer) {
        int i = getIndex(customer);
        if (i < 0) {
            return;
        }
        ele.set(i, ele.lastElement());
        ele.remove(ele.size() - 1);
    }
    
    /**
     * @effects <pre>
     *  if this is empty
     *    throw an IllegalStateException
     *  else
     *    return last element of this</pre>
     */
    public int chooseLast() throws IllegalStateException {
        if (size() > 0) {
            return (Integer) ele.lastElement();
        } else {
            throw new IllegalStateException("IllegalStateException: this set is empty!");
        }
    }

    /**
     * @overview <tt>IntSet.IntSetGen</tt> represents a generator of the
     * elements of an <tt>IntSet</tt>.
     * <p>
     * The abstraction function is:
     * <tt>AF(c) = [x1,...]</tt> such that each <tt>xi</tt>s are in and arranged
     * in same (arbitrary) order as
     * <tt>c.IntSet.els</tt>
     *
     */
    private class IntSetGen implements Iterator {

        private int ind;  // next index 

        /**
         *
         * @requires <tt>s</tt> is not <tt>null</tt>
         */
        public IntSetGen() {
            ind = -1;
        }

        public boolean hasNext() {
            return (ind < size() - 1);
        }

        public Object next() throws NoSuchElementException {
            if (ind < size() - 1) {
                ind++;
                return ele.get(ind);
            }

            throw new NoSuchElementException("NoSuchElementException happened");
        }

        public void remove() {
            // do nothing
        }
    } // end IntSetGen
}
