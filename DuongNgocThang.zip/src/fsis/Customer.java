/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fsis;

import kengine.NotPossibleException;

/**
 * @overview 
 *  Customers are people or organisations with which we have
 *  relationships. <br>
 * @attributes 
 *  id Integer 
 *  name String
 *  phoneNumber String 
 *  address String
 * @object 
 *  A typical Customer is c=<d,n,p,a>, where: id(d), name(n),
 *  phoneNumber(p), address(a).
 * @abstract_properties 
 *  mutable(id)=false /\ optional(id)=false /\ min(id)=1 /\
 *  max(id) = 1000000 /\ mutable(name)=true /\ optional(name)=false /\
 *  length(name)=50 mutable(phoneNumber)=true /\ optional(phoneNumber)=false /\
 *  length(phoneNumber)=10 /\ mutable(address)=true /\ optional(address)=false /\
 *  length(address)=100
 * @author
 * ThangDuong
 */
public class Customer implements Comparable, Document {

    
    @DomainConstraint(type = "Integer", mutable = false, optional = false, min = 1, max = 1000000)
    private int id;

    @DomainConstraint(type = "String", optional = false, length = 200)
    private String name;

    @DomainConstraint(type = "String", optional = false, length = 400)
    private String address;

    @DomainConstraint(type = "String", optional = false, length = 15)
    private String phoneNumber;

    /** constructor
     * @effects <pre>
    *            if d, n, p, a are not valid
    *              throws NotPossibleException
    *            else initialises this as Customer <d,n,p,a>
     */
    public Customer(int d, String n, String p, String a) throws NotPossibleException {
        if (!validate(d, n, p, a)) {
            throw new NotPossibleException("NotPossibleException: Invalid argument for constructor");
        } else {
            this.id = d;
            this.name = n;
            this.address = a;
            this.phoneNumber = p;
        }
    }

    
    /**
     * @effects <pre>
     *            if address is valid
     *              sets this.address = a
     *            else
     *              throws NotPossibleException</pre>
     */
    public void setAddress(String a) throws NotPossibleException {
        if (validateAddress(a)) {
            this.address = a;
        } else {
            throw new NotPossibleException("NotPossibleException: Invalid address " + a);
        }
    }

      
    /**
     * @effects <pre>
     *            if phone is valid
     *              set this.phoneNumber = p
     *            else
     *              throws NotPossibleException</pre>
     */
    public void setPhoneNumber(String p) throws NotPossibleException {
        if (validatePhone(p)) {
            this.phoneNumber = p;
        } else {
            throw new NotPossibleException("NotPossibleException: Invalid phone " + p);
        }
    }

    /**
     * @effects <pre>
     *            if name is valid
     *              sets this.name=name
     *            else
     *              throws NotPossibleException
     */
    public void setName(String n) throws NotPossibleException {
        if (validateName(n)) {
            this.name = n;
        } else {
            throw new NotPossibleException("NotPossibleException: Invalid name " + n);
        }
    }
    
    /**
     * @effects returns <tt>this.address</tt>
     */
    public String getAddress() {
        return address;
    }

    
    /**
     *
     * @effects returns <tt>this.id</tt>
     */
    public int getId() {
        return id;
    }

    /**
     * @effects returns <tt>this.name</tt>
     */
    public String getName() {
        return name;
    }

    /**
     * @effects returns <tt>this.phone</tt>
     */
    public String getPhoneNumber() {
        return phoneNumber;
    }

    
    @Override
    /**
     * effect return a string contains info of
     * customer
     */
    public String toString() {
        return "Customer info: " + id + " - " + name + " - " + phoneNumber + " - " + address;
    }

    // rep invariant methods
    /**
     * @effects <pre>
     *            if id, name, phone, address are valid
     *              return true
     *            else
     *              return false</pre>
     */
    private boolean validate(int id, String name, String phone, String address) {
        if (validateId(id) && validateName(name) && validatePhone(phone) && validateAddress(address)) {
            return true;
        } else {
            return false;
        }

    }

    /**
     * @effects <pre>
     *            if id is valid
     *              returns true
     *            else
     *              return false
     * </pre>
     */
    private boolean validateId(int id) {
        if (id > 0 && id < 1000000) {
            return true;
        }
        return false;
    }

    /**
     * @effects <pre>
     *            if name is valid
     *              returns true
     *            else
     *              return false
     * </pre>
     */
    private boolean validateName(String name) {
        if (name == null || name.length() > 200) {
            return false;
        }
        return true;
    }

    /**
     * @effects <pre>
     *            if phone is valid
     *              returns true
     *            else
     *              return false
     * </pre>
     */
    private boolean validatePhone(String phone) {
        if (phone == null || phone.length() > 15) {
            return false;
        }
        return true;
    }

    /**
     * @effects <pre>
     *            if address is valid
     *              returns true
     *            else
     *              return false
     * </pre>
     */
    private boolean validateAddress(String address) {
        if (address == null || address.length() > 400) {
            return false;
        }
        return true;
    }
    
    /**
     * @effects <pre>
     *            if this satisfies rep invariant
     *              returns true
     *            else
     *              returns false</pre>
     */
    public boolean repOK() {
        
        if (!validate(id, name, phoneNumber, address)) {
            return false;
        }

        return true;
    }


    @Override
    /**
     * effect return a string contains id, name, phone number, address, income
     * of customer in form of html Eg. <html>
     * <head><title>Customer:John</title></head>
     * <body>
     * 4 John 12345678 Hanoi
     * </body></html>
     */
    public String toHtmlDoc() {
        String s = "";
        s += "<html>";
        s += "<head><title>Customer: " + getName() + "</title></head>";
        s += "<body>";
        s += this.id + " " + this.name + " " + this.phoneNumber + " " + this.address;
        s += "</body></html>";
        return s;
    }
    
    @Override
    /**
     * effect return the result of comparing customer names
     */
    public int compareTo(Object o) throws NullPointerException, ClassCastException {
        if (o == null) {
            throw new NullPointerException("Object is null");
            
        } else if (!(o instanceof Customer)) {
            
            throw new ClassCastException("object is not a Customer " + o);
        }

        Customer customer = (Customer) o;
        return this.name.compareTo(customer.name);
    }
}
