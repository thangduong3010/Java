/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fsis;

import kengine.NotPossibleException;

/**
 * @overview
 *  HighEarner is a class to store info of rich and potential customer
 * @attributes 
 *  float income
 * @abstract_properties 
 *  mutable(income)=true /\ optional(id)=false /\
 *  min(income)=20000000
 * @object 
 *  A typical HighEarner customer is c=<d,n,p,a,i>, where id(d),
 *  name(n),phoneNumber(p), address(a), income(i).
 * @rep_invariant 
 *  income > 20000000
 * @author ThangDuong
 */
public class HighEarner extends Customer {

    
    @DomainConstraint(type = "Float", mutable = true, optional = false, min = 20000000)
    private float income;

    /**
     * @effects <pre>
     *            if d, n, p, a, i are not valid
     *              throws NotPossibleException
     *            else initialises this as Customer <d,n,p,a,i>
     */
    public HighEarner(int d, String n, String p, String a, float i) throws NotPossibleException {
        super(d, n, p, a);
        if (!validateIncome(i)) {
            throw new NotPossibleException("NotPossibleException: Invalid argument for constructor");
        } else {
            this.income = i;
        }
    }

    

    /**
     * @effects <pre>
     *            if address is valid
     *              sets this.income = income
     *            else
     *              throws NotPossibleException</pre>
     */
    public void setIncome(float i) throws NotPossibleException {
        if (validateIncome(i)) {
            this.income = i;
        } else {
            throw new NotPossibleException("NotPossibleException: Invalid income" + i);
        }
    }
    
    
    /**
     * @effects returns <tt>this.name</tt>
     */
    public float getIncome() {
        return income;
    }
    
    /**
     * effect return a string contains info
     * of high earner
     */
    public String toString() {
        return "High Earner info: " + super.getId() + " - " + super.getName() + " - "
                + super.getPhoneNumber() + " - " + super.getAddress() + " - " + income;

    }

    /**
     * @effects <pre>
     *            if income is valid
     *              returns true
     *            else
     *              return false
     * </pre>
     */
    private boolean validateIncome(float i) {
        if (i >= 20000000) {
            return true;
        }else{
            return false;
        }
    }

    /**
     * @effects <pre>
     *            if this satisfies rep invariant
     *              returns true
     *            else
     *              returns false</pre>
     */
    public boolean repOK() {
        return (super.repOK() && validateIncome(income));
    }


    @Override
    /**
     * effect return a string contains id, name, phone number, address, income
     * of high earner in form of html Eg. <html>
     * <head><title>Customer:John</title></head>
     * <body>
     * 4 John 12345678 Hanoi 17000000
     * </body></html>
     */
    public String toHtmlDoc() {
        String s = "";
        s += "<html>";
        s += "<head><title>Customer: " + getName() + "</title></head>";
        s += "<body>";
        s += this.getId() + " " + this.getName() + " " + this.getPhoneNumber() + " " + this.getAddress() + " " + income;
        s += "</body></html>";
        return s;
    }

}
